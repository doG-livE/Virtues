# Virtues
16-NOV-20
Cloned from the Virtues-Current project
Game design and development by Rick et all

Integrations with AWS
Support for game play and event tracking

Differences from Virtues-Current (as of writing)
    AWS tests are in the c.html (party) & vc.html (chat)
    Virtues.html has update to save to AWS
    Many JS functions seperated from .html files
    JSON still javascript object(s), but split from the .html
    Some bug fixes that were in the Virtues-Current were not mergred and are not included here.
